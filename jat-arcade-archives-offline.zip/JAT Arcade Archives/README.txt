JAT Arcade Archives - offline version

To play: double-click "Play JAT Arcade Archives.html". It opens in your web browser and needs
no internet connection and no installation. Works in current Chrome, Edge, Firefox and Safari.

High scores, your passport and your Maker Lab levels are saved in that browser on this computer.
Keep this folder together: the page needs museum.js next to it.

Controls: WASD or arrows to walk, drag to look, E or click to play, Space is the A button,
F for 2D full screen, Esc to stand up. Gamepads work too.

Free to play. If you enjoy it, you can support new rooms at https://cptnope.itch.io/jat-arcade-archives
Made by Jeremy Anderson - https://jeremyanderson.tech
Source: https://github.com/CptNope/JAT-Arcade-Archives
